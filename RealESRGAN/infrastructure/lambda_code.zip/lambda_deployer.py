import json
import boto3
import config
import time
from datetime import datetime

def lambda_handler(event, context):
    """ 
    Create a SM model + endpoint config + endpoint.
    If the endpoint already exists, it will be updated with a new endpoint config
    """
    sm_client = boto3.client("sagemaker")
    create_model_respose = sm_client.create_model(ModelName=config.MODEL_NAME, 
                              PrimaryContainer={
                                  'ModelPackageName':f'arn:aws:sagemaker:{config.REGION}:{config.ACCOUNT}:model-package/{config.MODEL_PACKAGE_NAME}/{event["detail"]["ModelPackageVersion"]}'
                              },
                              ExecutionRoleArn=config.EXECUTION_ROLE)
    
    ENDPOINT_CONFIG_NAME = 'RealESRGAN-Endpoint-Config-' + datetime.now().strftime("%HH-%MM-%SS")
    
    create_endpoint_config_response = sm_client.create_endpoint_config(
        EndpointConfigName=ENDPOINT_CONFIG_NAME,
        ProductionVariants=[
            {
                "InstanceType": config.INFERENCE_JOB_INSTANCE_TYPE,
                "InitialInstanceCount": config.INSTANCE_COUNT,
                "ModelName": config.MODEL_NAME,
                "VariantName": "AllTraffic",
            }
        ]
    )
    try:
        create_endpoint_response = sm_client.create_endpoint(EndpointName=config.ENDPOINT_NAME, 
                                                             EndpointConfigName=ENDPOINT_CONFIG_NAME)
        print('Model CREATED successfuly!')
    except:
        update_endpoint_response = sm_client.update_endpoint(EndpointName=config.ENDPOINT_NAME, 
                                                             EndpointConfigName=ENDPOINT_CONFIG_NAME)
        print('Model UPDATED successfuly!')
    
    return {
        "statusCode": 200,
        "body": json.dumps("Created Endpoint!"),
        "other_key": "example_value",
    }
            